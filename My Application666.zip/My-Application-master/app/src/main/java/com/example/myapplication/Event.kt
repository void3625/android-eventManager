package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class Event : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event)

        val signupButton = findViewById<Button>(R.id.signupButton)
        signupButton.setOnClickListener {
            showConfirmationDialog()
        }
    }

    private fun showConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("確定要報名嗎?")
            .setPositiveButton("是") { dialog, which ->
                // 這裡處理報名成功的邏輯
                // 例如顯示報名成功訊息或者保存報名信息
                showToast("報名成功")
            }
            .setNegativeButton("否") { dialog, which ->
                // 這裡可以處理任何返回活動頁面的邏輯
                dialog.dismiss()
            }
            .show()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
